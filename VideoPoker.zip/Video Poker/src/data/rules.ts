import type { PokerHand } from "../types/pokerhand";

export type PayoutRule = {
  hand: PokerHand;
  name: string;
  multiplier: number;
};

export const PAYOUT_RULES: PayoutRule[] = [
  { hand: "royal_flush", name: "Royal Flush", multiplier: 250 },
  { hand: "straight_flush", name: "Straight Flush", multiplier: 50 },
  { hand: "four_of_a_kind", name: "Four of a Kind", multiplier: 25 },
  { hand: "full_house", name: "Full House", multiplier: 9 },
  { hand: "flush", name: "Flush", multiplier: 6 },
  { hand: "straight", name: "Straight", multiplier: 4 },
  { hand: "three_of_a_kind", name: "Three of a Kind", multiplier: 3 },
  { hand: "two_pair", name: "Two Pair", multiplier: 2 },
  { hand: "jacks_or_better", name: "Jacks or Better", multiplier: 1 },
];
